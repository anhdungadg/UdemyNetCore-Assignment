﻿namespace $safeprojectname$.Models
{
    public class SampleModel
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string Version { get; set; }
    }
}
